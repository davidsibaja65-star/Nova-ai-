package com.novaai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090B16)
private val Panel = Color(0xFF151A2D)
private val Purple = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF38BDF8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaApp() }
    }
}

@Composable
fun NovaApp() {
    var page by remember { mutableStateOf("Inicio") }
    var prompt by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("¡Hola! Soy Nova AI. El asistente inteligente estará conectado cuando configuremos el servicio de IA.") }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Purple,
        secondary = Cyan, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    listOf("Inicio", "Chat", "Crear", "Perfil").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(when(item) {
                                    "Inicio" -> Icons.Default.Home
                                    "Chat" -> Icons.Default.Chat
                                    "Crear" -> Icons.Default.AutoAwesome
                                    else -> Icons.Default.Person
                                }, contentDescription = item)
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Cyan, selectedTextColor = Cyan,
                                indicatorColor = Purple.copy(alpha = .18f),
                                unselectedIconColor = Color.LightGray,
                                unselectedTextColor = Color.LightGray
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when(page) {
                "Chat" -> ChatScreen(prompt, { prompt = it }, answer, { answer = it }, Modifier.padding(padding))
                "Crear" -> CreateScreen(Modifier.padding(padding))
                "Perfil" -> ProfileScreen(Modifier.padding(padding))
                else -> HomeScreen(Modifier.padding(padding), onOpen = { page = it })
            }
        }
    }
}

@Composable
fun Header() {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).background(
            Brush.linearGradient(listOf(Purple, Cyan)), RoundedCornerShape(14.dp)
        ), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.AutoAwesome, null, tint = Color.White)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("NOVA AI", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
            Text("Tu inteligencia, sin límites", color = Color.LightGray, fontSize = 11.sp)
        }
        Spacer(Modifier.weight(1f))
        Surface(color = Purple.copy(alpha = .18f), shape = RoundedCornerShape(20.dp)) {
            Text("FREE", Modifier.padding(horizontal = 13.dp, vertical = 7.dp), color = Cyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier, onOpen: (String) -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(top = 22.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item { Header() }
        item {
            Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF30205F), Color(0xFF102D4A))), RoundedCornerShape(24.dp)).padding(22.dp)) {
                Text("HOLA, BIENVENIDO", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(8.dp))
                Text("¿Qué vamos a
crear hoy?", fontSize = 29.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Conversa, aprende, crea y organiza tus ideas con Nova.", color = Color(0xFFD7D8E8))
                Spacer(Modifier.height(18.dp))
                Button(onClick = { onOpen("Chat") }, colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                    Text("Comenzar a chatear"); Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, null)
                }
            }
        }
        item { Text("HERRAMIENTAS NOVA", color = Color.LightGray, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                FeatureCard("Nova Chat", "Habla con tu asistente inteligente", Icons.Default.Chat, Cyan) { onOpen("Chat") }
                FeatureCard("Nova Estudiante", "Tareas, resúmenes e investigaciones", Icons.Default.School, Purple) { onOpen("Chat") }
                FeatureCard("Nova Music", "Ideas para canciones e instrumentales", Icons.Default.MusicNote, Color(0xFFF472B6)) { onOpen("Crear") }
                FeatureCard("Nova Image", "Crea conceptos e imágenes", Icons.Default.Image, Color(0xFFFBBF24)) { onOpen("Crear") }
                FeatureCard("Nova Documents", "Organiza tus documentos", Icons.Default.Description, Cyan) { onOpen("Crear") }
                FeatureCard("Nova Voice", "Prepara tu experiencia de voz", Icons.Default.Mic, Purple) { onOpen("Crear") }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(18.dp)) {
                Text("NOVA PREMIUM", color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("$150 MXN / mes", fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                Text("7 días de prueba gratis. Después, suscripción mensual cancelable.", color = Color.LightGray, fontSize = 12.sp)
                Text("La suscripción y el cobro se habilitarán al conectar Google Play Billing.", color = Color(0xFFFFD580), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

@Composable
fun FeatureCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).clickable { onClick() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(46.dp).background(tint.copy(alpha = .15f), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = tint)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Color.LightGray, fontSize = 12.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Color.LightGray)
    }
}

@Composable
fun ChatScreen(prompt: String, onPrompt: (String) -> Unit, answer: String, onAnswer: (String) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Header()
        Text("Nova Chat", fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 28.dp))
        Text("Tu espacio de conversación", color = Color.LightGray)
        Spacer(Modifier.height(20.dp))
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().weight(1f)) {
            Column(Modifier.padding(16.dp)) {
                Text("NOVA AI", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Text(answer)
                Spacer(Modifier.height(14.dp))
                Text("Nota: esta versión es una interfaz inicial; todavía no está conectada a un modelo de IA.", color = Color(0xFFFFD580), fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(prompt, onPrompt, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Escribe tu mensaje...") }, shape = RoundedCornerShape(16.dp))
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            onAnswer(if (prompt.isBlank()) "Escribe una pregunta para comenzar." else "Tu mensaje: “$prompt”\n\nLa conexión con el servicio de IA se añadirá en la siguiente etapa.")
            onPrompt("")
        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
            Icon(Icons.Default.Send, null); Spacer(Modifier.width(8.dp)); Text("Enviar")
        }
    }
}

@Composable
fun CreateScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Header()
        Text("Centro creativo", fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 28.dp))
        Text("Elige lo que quieres preparar", color = Color.LightGray)
        Spacer(Modifier.height(18.dp))
        FeatureCard("Nova Music", "Generación musical: integración pendiente", Icons.Default.MusicNote, Color(0xFFF472B6)) {}
        Spacer(Modifier.height(12.dp))
        FeatureCard("Nova Image", "Generación de imágenes: integración pendiente", Icons.Default.Image, Color(0xFFFBBF24)) {}
        Spacer(Modifier.height(12.dp))
        FeatureCard("Nova Documents", "Importación y creación de archivos: pendiente", Icons.Default.Description, Cyan) {}
        Spacer(Modifier.height(12.dp))
        FeatureCard("Nova Voice", "Conversación por voz: integración pendiente", Icons.Default.Mic, Purple) {}
    }
}

@Composable
fun ProfileScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Header()
        Text("Tu cuenta", fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 28.dp))
        Text("Registro e inicio de sesión se conectarán en la siguiente etapa.", color = Color.LightGray)
        Spacer(Modifier.height(18.dp))
        FeatureCard("Iniciar sesión con Google", "Acceso rápido y seguro", Icons.Default.AccountCircle, Cyan) {}
        Spacer(Modifier.height(10.dp))
        FeatureCard("Correo y contraseña", "Crear cuenta o iniciar sesión", Icons.Default.Email, Purple) {}
        Spacer(Modifier.height(10.dp))
        FeatureCard("Panel de administrador", "Área privada del propietario (pendiente)", Icons.Default.AdminPanelSettings, Color(0xFFFBBF24)) {}
        Spacer(Modifier.height(18.dp))
        Text("Nova AI • Versión inicial 1.0.0", color = Color.Gray, fontSize = 12.sp)
    }
}
