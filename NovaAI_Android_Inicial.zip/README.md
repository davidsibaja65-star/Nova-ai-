# Nova AI — proyecto Android inicial

Este ZIP contiene una **primera base visual Android** hecha con Kotlin y Jetpack Compose.

## Qué incluye
- Interfaz oscura futurista con acentos morado/azul.
- Inicio y secciones Nova Chat, Estudiante, Music, Image, Documents y Voice.
- Pantalla de perfil y presentación de Nova Premium a $150 MXN/mes con 7 días de prueba.
- Navegación inferior.

## Qué todavía NO está conectado
Esta versión es una maqueta funcional de navegación, no una IA comercial terminada:
- Chat IA y voz requieren conectar un backend y un proveedor de modelos.
- Música e imágenes requieren servicios de generación, controles de uso y presupuesto.
- Google Sign-In y correo/contraseña requieren autenticación real.
- Premium requiere backend de suscripciones y Google Play Billing.
- El panel de administrador debe ser una web privada protegida y conectada al backend.
- Historial, documentos y modo offline requieren implementación adicional.

**No publiques esta versión como producto terminado ni cobres suscripciones todavía.**

## Compilar
Abre el proyecto en Android Studio, espera la sincronización de Gradle y ejecuta la app en un dispositivo Android. Requiere JDK 17 y Android SDK 35.
Para generar un APK: Android Studio > Build > Build Bundle(s) / APK(s) > Build APK(s).

## Seguridad
Nunca incluyas claves privadas de APIs en el APK. Las llamadas a servicios de IA y la validación de suscripciones deben pasar por un backend seguro.
